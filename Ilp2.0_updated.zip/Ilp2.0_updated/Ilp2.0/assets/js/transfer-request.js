(() => {

    const RESOURCE_KEY = "curonexResources";
    const TRANSFER_KEY = "curonexTransfers";

    const form = document.getElementById("transferForm");

    if (!form) {
        return;
    }

    // ==========================================
    // ELEMENTS
    // ==========================================

    const clearHistoryButton =

    document.getElementById(

        "clearHistoryBtn"

    );

    const resourceDropdown =
        document.getElementById("transferResource");

    const sourceDropdown =
        document.getElementById("transferSource");

    const destinationDropdown =
        document.getElementById("transferDestination");

    const quantityInput =
        document.getElementById("transferQuantity");

    const priorityDropdown =
        document.getElementById("transferPriority");

    const notesInput =
        document.getElementById("transferNotes");

    const quantityHelper =
        document.getElementById("quantityHelper");

    const resourceInfo =
        document.getElementById("resourceInfo");

    const resourceCategory =
        document.getElementById("resourceCategory");

    const resourceType =
        document.getElementById("resourceType");

    const availableQuantity =
        document.getElementById("availableQuantity");

    const resourceUnit =
        document.getElementById("resourceUnit");

    const tableBody =
        document.getElementById("transferTableBody");

    const totalOrders =
        document.getElementById("totalOrders");

    const resourcesTransferred =
        document.getElementById("resourcesTransferred");

    const hospitalsInvolved =
        document.getElementById("hospitalsInvolved");

    const totalTransferredQuantity =
        document.getElementById("totalTransferredQuantity");

    // ==========================================
    // LOCAL STORAGE
    // ==========================================

    function readList(key) {

        try {

            const value =
                localStorage.getItem(key);

            if (!value) {
                return [];
            }

            const parsed =
                JSON.parse(value);

            return Array.isArray(parsed)
                ? parsed
                : [];

        }

        catch {

            return [];

        }

    }

    function writeList(key, list) {

        localStorage.setItem(
            key,
            JSON.stringify(list)
        );

    }

    // ==========================================
    // STATUS
    // ==========================================

    function calculateStatus(quantity) {

        if (quantity <= 0) {

            return "Out of Stock";

        }

        if (quantity < 20) {

            return "Low Stock";

        }

        return "Available";

    }

    // ==========================================
    // RESOURCES
    // ==========================================

    function getResources() {

        return readList(RESOURCE_KEY);

    }

    function getTransfers() {

        return readList(TRANSFER_KEY);

    }

        // ==========================================
    // POPULATE RESOURCE DROPDOWN
    // ==========================================

    function populateResources() {

        const resources = getResources();

        const uniqueResources =
            [...new Map(

                resources.map(resource => [

                    resource.resourceName,

                    resource

                ])

            ).values()];

        resourceDropdown.innerHTML =

            `<option value="">Select Resource</option>`;

        uniqueResources.forEach(resource => {

            resourceDropdown.innerHTML += `

                <option value="${resource.resourceName}">

                    ${resource.resourceName}

                </option>

            `;

        });

    }

    // ==========================================
    // POPULATE SOURCE HOSPITAL
    // ==========================================

    function populateSourceHospitals(resourceName) {

        const resources = getResources()

            .filter(resource =>

                resource.resourceName === resourceName &&
                Number(resource.quantity) > 0

            );

        sourceDropdown.innerHTML =

            `<option value="">Select Source Hospital</option>`;

        resources.forEach(resource => {

            sourceDropdown.innerHTML += `

                <option value="${resource.hospital}">

                    ${resource.hospital}

                </option>

            `;

        });

    }

    // ==========================================
    // POPULATE DESTINATION
    // ==========================================

    

    // ==========================================
    // SHOW RESOURCE DETAILS
    // ==========================================

    function displayResourceInformation() {

        const selectedResource =
            resourceDropdown.value;

        const selectedHospital =
            sourceDropdown.value;

        if (!selectedResource ||
            !selectedHospital) {

            resourceInfo.style.display = "none";

            quantityHelper.textContent =
                "Available : --";

            return;

        }

        const resource =

            getResources()

            .find(item =>

                item.resourceName === selectedResource &&

                item.hospital === selectedHospital

            );

        if (!resource) {

            resourceInfo.style.display = "none";

            return;

        }

        resourceInfo.style.display = "block";

        resourceCategory.textContent =
            resource.category;

        resourceType.textContent =
            resource.resourceType;

        availableQuantity.textContent =
            resource.quantity;

        resourceUnit.textContent =
            resource.unit;

        quantityHelper.textContent =

            `Available : ${resource.quantity} ${resource.unit}`;

    }

    // ==========================================
    // EVENTS
    // ==========================================

    
    


    populateResources();

    resourceDropdown.addEventListener(

    "change",

    () => {

        populateSourceHospitals(

            resourceDropdown.value

        );

        displayResourceInformation();

    }

);
    // ==========================================
// RESOURCE CHANGE EVENT
// ==========================================

sourceDropdown.addEventListener(

    "change",

    displayResourceInformation

);

        // ==========================================
    // CREATE TRANSFER ORDER
    // ==========================================

    form.addEventListener("submit", (event) => {

        event.preventDefault();

        const resourceName = resourceDropdown.value;
        const sourceHospital = sourceDropdown.value;
        const destinationHospital = destinationDropdown.value;
        const transferQuantity = Number(quantityInput.value);
        const priority = priorityDropdown.value;
        const notes = notesInput.value.trim();

        // -----------------------------
        // VALIDATIONS
        // -----------------------------

        if (!resourceName) {

            alert("Please select a resource.");
            return;

        }

        if (!sourceHospital) {

            alert("Please select the source hospital.");
            return;

        }

        if (!destinationHospital) {

            alert("Please select the destination hospital.");
            return;

        }

        if (sourceHospital === destinationHospital) {

            alert("Source and Destination hospitals cannot be the same.");
            return;

        }

        if (!transferQuantity || transferQuantity <= 0) {

            alert("Enter a valid transfer quantity.");
            return;

        }

        const resources = getResources();

        const sourceResource = resources.find(resource =>

            resource.resourceName === resourceName &&
            resource.hospital === sourceHospital

        );

        if (!sourceResource) {

            alert("Selected resource not found.");
            return;

        }

        if (transferQuantity > Number(sourceResource.quantity)) {

            alert("Transfer quantity exceeds available stock.");

            return;

        }

        // -----------------------------
        // REDUCE SOURCE QUANTITY
        // -----------------------------

        sourceResource.quantity -= transferQuantity;

        sourceResource.status = calculateStatus(
            sourceResource.quantity
        );

        // -----------------------------
        // FIND DESTINATION
        // -----------------------------

        let destinationResource = resources.find(resource =>

            resource.resourceName === resourceName &&
            resource.hospital === destinationHospital

        );

        if (destinationResource) {

            destinationResource.quantity += transferQuantity;

            destinationResource.status = calculateStatus(
                destinationResource.quantity
            );

        }

        else {

            destinationResource = {

                id: "resource-" + Date.now(),

                resourceName: sourceResource.resourceName,

                category: sourceResource.category,

                quantity: transferQuantity,

                unit: sourceResource.unit,

                hospital: destinationHospital,

                supplier: sourceResource.supplier,

                batchNumber: sourceResource.batchNumber,

                resourceType: sourceResource.resourceType,

                description: sourceResource.description,

                status: calculateStatus(
                    transferQuantity
                ),

                createdAt: new Date().toISOString()

            };

            resources.push(destinationResource);

        }

        // -----------------------------
        // SAVE UPDATED RESOURCES
        // -----------------------------

        writeList(

            RESOURCE_KEY,

            resources

        );

        // -----------------------------
        // SAVE TRANSFER ORDER
        // -----------------------------

        const transfers = getTransfers();

        transfers.unshift({

            id: "TR-" + Date.now(),

            resourceName,

            sourceHospital,

            destinationHospital,

            quantity: transferQuantity,

            unit: sourceResource.unit,

            priority,

            notes,

            status: "Order Placed",

            orderDate: new Date().toISOString()

        });

        writeList(

            TRANSFER_KEY,

            transfers

        );

        // -----------------------------
        // SUCCESS
        // -----------------------------

        alert("Transfer Order Placed Successfully.");

        form.reset();

        resourceInfo.style.display = "none";

        quantityHelper.textContent =

            "Available : --";

        populateResources();

        window.dispatchEvent(

            new Event("curonex-resources-updated")

        );

        window.dispatchEvent(

            new Event("curonex-transfers-updated")

        );

    });

        // ==========================================
    // RENDER ORDER TABLE
    // ==========================================

    function renderTransferTable() {

        const transfers = getTransfers();

        if (!tableBody) {
            return;
        }

        if (transfers.length === 0) {

            tableBody.innerHTML = "";

            const emptyState =

            document.getElementById(

                "transferEmptyState"

            );

        if (emptyState) {

            emptyState.style.display =

                transfers.length === 0

                    ? "block"

                    : "none";

        }

            updateSummary();

            return;

        }

        document
            .getElementById("transferEmptyState")
            .style.display = "none";

        tableBody.innerHTML = "";

        transfers.forEach(order => {

            const date = new Date(
                order.orderDate
            ).toLocaleString();

            tableBody.innerHTML += `

                <tr>

                    <td>${order.id}</td>

                    <td>${order.resourceName}</td>

                    <td>${order.sourceHospital}</td>

                    <td>${order.destinationHospital}</td>

                    <td>

                        ${order.quantity}
                        ${order.unit}

                    </td>

                    <td>

                        ${order.priority}

                    </td>

                    <td>

                        ${date}

                    </td>

                    <td>

                        <span class="status available">

                            ${order.status}

                        </span>

                    </td>

                    <td>

                        <button
                            class="delete-btn"
                            data-id="${order.id}">

                            <i class="fa-solid fa-trash"></i>

                            Delete

                        </button>

                    </td>

                </tr>

            `;

        });

        updateSummary();

    }

    // ==========================================
// DELETE TRANSFER
// ==========================================

function deleteTransfer(orderId) {

    if (

        !confirm(

            "Delete this transfer record?"

        )

    ) {

        return;

    }

    const updatedTransfers =

        getTransfers().filter(

            order => order.id !== orderId

        );

    writeList(

        TRANSFER_KEY,

        updatedTransfers

    );

    renderTransferTable();

}

// ==========================================
// CLEAR HISTORY
// ==========================================

function clearTransferHistory() {

    if (

        !confirm(

            "Delete all transfer history?"

        )

    ) {

        return;

    }

    writeList(

        TRANSFER_KEY,

        []

    );

    renderTransferTable();

}


    // ==========================================
    // SUMMARY
    // ==========================================

    function updateSummary() {

        const transfers = getTransfers();

        if (totalOrders) {

            totalOrders.textContent =
                transfers.length;

        }

        if (resourcesTransferred) {

            const uniqueResources =

                new Set(

                    transfers.map(order =>
                        order.resourceName
                    )

                );

            resourcesTransferred.textContent =
                uniqueResources.size;

        }

        if (hospitalsInvolved) {

            const hospitals =

                new Set();

            transfers.forEach(order => {

                hospitals.add(
                    order.sourceHospital
                );

                hospitals.add(
                    order.destinationHospital
                );

            });

            hospitalsInvolved.textContent =
                hospitals.size;

        }

        if (totalTransferredQuantity) {

            const total =

                transfers.reduce(

                    (sum, order) =>

                        sum + Number(order.quantity),

                    0

                );

            totalTransferredQuantity.textContent =
                total;

        }

    }

    // ==========================================
    // SEARCH
    // ==========================================

    const searchInput =
        document.getElementById("transferSearch");

    if (searchInput) {

        searchInput.addEventListener(

            "input",

            () => {

                const value =

                    searchInput.value
                        .trim()
                        .toLowerCase();

                const rows =
                    tableBody.querySelectorAll("tr");

                rows.forEach(row => {

                    row.style.display =

                        row.innerText
                            .toLowerCase()
                            .includes(value)

                        ? ""

                        : "none";

                });

            }

        );

    }

    // ==========================================
    // INITIAL LOAD
    // ==========================================

    renderTransferTable();

    window.addEventListener(

        "curonex-transfers-updated",

        renderTransferTable

    );

    // ==========================================
// DELETE BUTTON EVENT
// ==========================================

tableBody.addEventListener("click", (event) => {

    const deleteButton = event.target.closest(".delete-btn");

    if (!deleteButton) {

        return;

    }

    deleteTransfer(

        deleteButton.dataset.id

    );

});

if (clearHistoryButton) {

    clearHistoryButton.addEventListener(

        "click",

        clearTransferHistory

    );

}

})();

